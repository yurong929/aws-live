<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

	$request = $_REQUEST; //a PHP Super Global variable which used to collect data after submitting it from the form
	$name = $request['name']; 
    $phone = $request['phone'];
    $date = $request['date'];
    $time = $request['time'];
    $people = $request['people'];
      
	define('DB_SERVER', 'beautydb.cvyvi4x2qpcd.us-east-1.rds.amazonaws.com');
	define('DB_USERNAME', 'admin');
	define('DB_PASSWORD', 'beautyinthepot');
	define('DB_DATABASE', 'beautydb');
	
	$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

	if ($mysqli->connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	  exit();
	}

	// Set the INSERT SQL data
	$sql = "INSERT INTO bookings (name, phone, name, time, people)
	VALUES ('".$name."', '".$phone."', '".$date."', '".$time."', , '".$people."')";

	// Process the query so that we will save the date of birth
	if ($mysqli->query($sql)) {
	  echo "Bookings has been successfully created.";
	} else {
	  return "Error: " . $sql . "<br>" . $mysqli->error;
	}

	// Close the connection after using it
	$mysqli->close();
?>