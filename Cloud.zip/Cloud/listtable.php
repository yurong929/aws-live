<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->

<!DOCTYPE html>
<html lang="en">
<head>
     <style>
        table,td,th,tr{
            border:1px solid #cda45e;
            color:#cda45e;
        }
        
        #table1{
            border-collapse: collapse;
            text-align: center;
            width: 100%;
        }
        
        table{
            width: 97%;
            margin: 10px auto;
            border-collapse: collapse;
        }

        td{
            padding: 8px 15px;
            border:2px solid white;
            color:white;
            font-weight:bold;
        }
        
        .edit{
            color:white;
            border: 2px solid white;
            border-radius: 8px;
            padding: 5px;
            width:8%;
            height:50%;
            background-color:red;
            
        }
        
        .remove{
            margin-left:10px;
            color:white;
            border: 2px solid white;
            border-radius: 8px;
            padding: 5px;
            width:9%;
            height:50%;
            background-color:red;
        }
        
        .edit:hover,.remove:hover{
            background-color:#ff6666;
            color:black;
        }
    </style>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Beauty In The Pot</title>
  <meta content="" name="keywords">
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

   <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-cente">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-lg-between">

      <h1 class="logo me-auto me-lg-0"><a href="index.html">Beauty In The Pot.</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->

    </div>
  </header><!-- End Header -->
       
    <section id="book-a-table" class="book-a-table" style="margin-top:10px;">
      <div class="container" data-aos="fade-up">
          <div class="section-header"><br><br><br>
              <h2 style="font-size: 25px;color:#cda45e;font-weight:bold;;margin-top:30px;text-align:center;">Customer Book Table Lists</h2>
        </div>
            <table id="table1">
                <thead style="border-bottom: 1px solid black;">
                    <tr>
                        <th class="name" id="name">Name</th>
                        <th class="phone" id="phone">Phone</th>
                        <th class="date" id="date">Date</th>
                        <th class="time" id="time">Time</th>
                        <th class="people" id="people">People</th>
                    </tr>
                </thead>
                <tbody style="font-weight:normal;">
                    <tr>
                        <td>test</td>
                            <?php
                                $data1 = mysqli_query($mysqli,"SELECT * FROM bookings");
                                    $no = 1;
                                    //print out data from database
                                    while($info1=mysqli_fetch_array($data1)){

                                ?>
                                    <td><?php echo $info1['name'];?></td>
                                    <td><?php echo $info1['phone'];?></td>
                                    <td><?php echo $info1['date'];?></td>
                                    <td><?php echo $info1['time'];?></td>
                                    <td><?php echo $info1['people'];?></td>
                                   
                            <div class="form_action--button">
                            <button class="edit"><?php echo '<form method="POST" action="edit.php"></form>'?>Edit</button>               
                            <button class="remove"><?php echo '<form method="POST" action="delete.php"></form>'?>Remove</button>
                            </div>
                
                            <?php
                                        $no++;
                                    }
                            ?>
                    </tr>
                </tbody>
            </table>
      </div>
    </section>
  
 
    

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
