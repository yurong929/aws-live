<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

        $servername = "beautydb.cvyvi4x2qpcd.us-east-1.rds.amazonaws.com"; //set the servername
        $username = "admin"; //set the server username
        $password = "beautyinthepot"; // set the server password (you must put password here if your using live server)
        $dbname = "beautydatabase"; // set the table name
        
        $mysqli = new mysqli($servername, $username, $password, $dbname);

	if ($mysqli->connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	  exit();
	}
        
            $sql = "DELETE FROM bookings WHERE name='" . $_GET["name"] . "'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Record deleted successfully";
                header('Location: listtable.php');
            } else {
                echo "Error deleting record: " . mysqli_error($mysqli);
            }
            mysqli_close($mysqli);
            
?>